/*1
Необходимо создать функцию myFunction, которая принимает два числовых аргумента a и b, 
Найти сумму четных чисел и их количество в диапазоне от a(начало диапазона) до b(конец диапазона)
Для вывода результата из функции используем console.log("ваш результат");

Пример вызова: myFunction(3, 5);

Пример вывода: Сумма четных чисел в диапазоне равна: 4

            Количество четных чисел в диапазоне равно: 1

*/


function summyFunction(a, b,) {
    let sum = 0;
    let count = 0;
    for (let i = a; i <= b;  i++)
    if (i % 2 == 0)
            sum += i;
    count++;
    console.log('Сумма четных чисел в диапазоне равна: ', sum);
    console.log(' Количество четных чисел в диапазоне равно: ', count);
}
summyFunction(3, 5,);

/*2
Необходимо создать функцию isPrime, которая принимает одно число num. 
Функция определяет простое ли число (число называется простым, если оно делится только само на себя и на 1)
Функция должна возвращать значение типа boolean(true/false);

Пример вызова: isPrime(7);

            isPrime(9);

Примеры возвращаемого значения:  true;
                                false;

*/

function isPrime(num) {
    let memory = true;
    if (num > 1) {
        for (let i = 2; i < num; i++) {
            if (num % i === 0) {
                memory = false;
            }
        }
    } else memory = false
    return memory;
}
console.log(isPrime(7)); 

/*3
Необходимо создать 2 функции getSqrtBySequentialSelection и getSqrtByBinarySearch каждая из которых принимают один аргумент number(число) обе функции будут находить и возвращать корень натурального числа с точностью до целого(аналогично вызову Math.sqrt(number)). 
Соответственно результат выполнения у двух функций будет одинаковый, а реализация разная.
getSqrtBySequentialSelection будет находить корень методом последовательного подбора;
getSqrtByBinarySearch будет находить корень методом бинарного поиска;
Math.sqrt в задании использовать нельзя. 

Пример вызова:  getSqrtBySequentialSelection(4); getSqrtByBinarySearch(9);
Примеры возвращаемого значения:  2;3;

*/
let getSqrtByBinarySearch = function(number) {
    let y = 0;
    let x = number;
    let sqrt = 0;
    
    while (sqrt <= x) {
        const middle = Math.trunc((sqrt + x) / 2);
        if (middle * middle === number) {
            return middle;
        }
        else if (middle * middle < number) {
            sqrt = middle + 1;
            y = middle;
        }
        else {
            x = middle - 1;
        }
    }
    return y;
};
console.log(getSqrtByBinarySearch(9));


function getSqrtBySequentialSelection(numer) {
    for (i = 0; i <= numer; i++){
        if (i ** 2 == numer) {
            return i;
        }
    }
}
console.log(getSqrtBySequentialSelection(4));


/*4
Необходимо создать функцию getFactorial, которая принимает одно число n. 
Функция возвращает факториал числа n.(n! = 1*2*…*n-1*n)

Пример вызова:  getFactorial(4); getFactorial(5);
Примеры возвращаемого значения:  24; 120;

*/

function getFactorial(n) {
    return (n != 1) ? n * getFactorial(n - 1) : 1;
}
console.log(getFactorial(4));

/*5
Необходимо создать функцию digitSum, которая принимает одно число y. 
Функция возвращает сумму цифр заданного числа

Пример вызова:  digitSum(128); digitSum(1); digitSum(5659);
Примеры возвращаемого значения:   11; 1;

*/

function digitSum(y) {
    let figures = "" + y;
    let sum = 0;
    for (let i = 0; i < figures.length; i++) 
        sum += +figures[i]
    return sum;
}
console.log(digitSum(128));










